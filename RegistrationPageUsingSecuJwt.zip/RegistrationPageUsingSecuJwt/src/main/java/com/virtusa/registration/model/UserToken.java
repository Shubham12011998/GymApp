package com.virtusa.registration.model;

public class UserToken {
    String userToken;
    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }



}
